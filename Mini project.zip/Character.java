import java.util.Random;

public class Character  {
    private String name; // character info
    private int ATK;
    private int Level;
    private int HP;
    private int DEF;

    public Character(String Name, int Attack, int LVL, int hp, int mp, int def){ //constructer
        name=Name;
        ATK= Attack;
        Level=LVL;
        HP=hp;
        DEF=def;
    }

    public String getDescription(){
        return "This is a "+name+"\n [LVL]: "+Level+"\n [ATK]: "+ATK+"\n[DEF]: "+DEF; //returns stats of character
    }


    public int Attack(Character character){
        Random random= new Random();
        int damage=ATK*100/(100+character.getDEF());  //calculates damage based on enemy's defense
        int finaldamage=random.nextInt(damage - (damage-2) + 1) + (damage-2); // adjusts damage to have an element of randomness
        character.HP-= finaldamage;
        System.out.println("The "+name+" hits back at "+character.getName()+" dealing "+finaldamage+" damage!"); // prints the damage results
        return damage; 
    }



    public String getName(){ //getters and setters
        return name;
    }

    public int getLevel(){
        return Level;
    }

    public int getHP(){
        return HP;
    }

    public int getDEF(){
        return DEF;
    }

    public int getATK(){
        return ATK;
    }

    public void setLevel(int level){
        Level+=level;
    }
    public void setHP(int amount, boolean add) { // boolean parameter to choose whether to add or subtract
        if (add){
            HP += amount;
        }
        else{
            HP -= amount;
        }

    }

    public void setATK(int Attack){
        ATK=Attack;
    }
    public void setDEF(int defence , boolean add){ 

        if (add){
            DEF+=defence;
        }
        else{
            DEF-=defence;
        }

    }
}
