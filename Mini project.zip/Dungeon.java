import java.util.Random;

import java.util.Random;

public class Dungeon {
    private int rooms;
    private int currentroom;
    private int steps;
    private int stepsToRoom;

    public Dungeon(int rooms){
        steps=0;
        this.rooms= rooms;
        currentroom=1;
        stepsToRoom=4;
    }

    public int getSteps(){
        return steps;
    }

    public int getStepsToRoom(){
        return stepsToRoom;
    }

    public void setCurrentroom(int room){
        currentroom+=room;

    }
    public int getCurrentroom(){
        return  currentroom;
    }




    public String getRoom(){
        return("You are currently in room: "+currentroom);

    }

    public Enemy battles(int currentroom) {
        if (currentroom == 2) {
            Enemy Troll = new troll(3);
            return Troll;
        }
        if (currentroom == 3) {
            Enemy vampire = new Vampire(4);
        }
        if (currentroom == 4) {
            Enemy diana = new Diana(5);
            return diana;
        }
        else{
            return null;
        }
    }

    public void Step(){
        steps+=1;
    }
    public String getRooms(){
        return("There are "+rooms  + "in this dungeon");

    }
}

