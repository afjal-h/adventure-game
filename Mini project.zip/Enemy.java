import java.util.Random;
public class Enemy extends Character {


    public Enemy(String Name, int Attack, int LVL, int hp, int mp, int def){
        super(Name, Attack,LVL,hp,mp,def); // constructs stats using character superclass
    }

    public String getDescription(){
        return "This is an enemy"; // polymorphism description
    }

    public String getPortrait(){ 
        return "";
    }
    
            public int Attack(Character character){
        Random random= new Random();
        int damage=getATK()*100/(80+character.getDEF()); // adjusted damage calculation
        int finaldamage=random.nextInt(damage - (damage-5) + 1) + (damage-5);
        character.setHP(finaldamage,false);
        System.out.println("The "+getName()+" hits back at "+character.getName()+" dealing "+finaldamage+" damage!");
        return damage;
    }


}

