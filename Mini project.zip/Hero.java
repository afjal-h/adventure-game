import java.util.Random;



public class Hero extends Character { 
    private int XP;
    private int XPnext;
    private int MaxHP;
    private int MP;
    Potion potions;
    boolean weaponEquipped;

    public Hero(String Name, int Attack, int LVL, int hp, int mp, int def){
        super(Name, Attack,LVL,hp,mp,def); // constructs stats using character superclass
        MaxHP= getHP(); // used for healing calculations
        XPnext=10; // initial level 1 xp goal
        potions= new Potion(5); // creates 5 potions for new hero
        weaponEquipped=false;

    }


    public void Heal(Hero player){
        potions.Heal(player); //calls method from potion object class

    }

    public void levelUp(){
        if(XP>=XPnext){
            System.out.println("You have levelled up!");
            setLevel(1); // sets new stats when the player has reached maxXP
            setATK(5);
            setHP(10,true);
            MP+=5;
            setDEF(5,true);
            XP= 0+(XP-XPnext); //adds excess xp when level up
            XPnext+= (XPnext*2); // new xp goal 
        }
    }

    public void equipWeapon(Weapon newItem, Weapon currentItem){
        if (weaponEquipped){
            setATK(-(currentItem.getATK())); //unequips current item
        }
        else{
            setATK(newItem.getATK());
        }
    }
    public boolean deathCheck(){
        if (getHP()<=0){ //if hp is 0 or less it will return true
            return true;
        }
        else{return false;}

    }

    public void increaseXP(double amount){ // increases xp variable by parameter amount
        XP+= amount;
    }

    public int getXP(){ //getters and setters 
        return XP;
    }

    public int getXPnext(){
        return XPnext;
    }

    public int getMaxHP(){
        return MaxHP;
    }

}

