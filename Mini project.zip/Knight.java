class Knight extends Hero{ // Main character for player

    public Knight() {
        super("Knight", 15, 1, 30, 5, 8);
    }
}