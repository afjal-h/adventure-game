import java.util.Random;
import java.util.Scanner;
import java.lang.Math;

public class Main {
    public static void main(String[] args) {
        intro();

    }

    public static void intro() {
        print("+--------------------------------------------------------------------------------------------+",1);
        print(" RELEASE                         Untitled Adventure Game                          ALPHA BUILD",1);
        print("                     ______\n" +
                "                  .-\"      \"-.\n" +
                "                 /            \\\n" +
                "                |              |\n" +
                "                |,  .-.  .-.  ,|\n" +
                "                | )(__/  \\__)( |\n" +
                "                |/     /\\     \\|\n" +
                "      (@_       (_     ^^     _)\n" +
                " _     ) \\_______\\__|IIIIII|__/__________________________\n" +
                "(_)@8@8{}<________|-\\IIIIII/-|___________________________>\n" +
                "       )_/        \\          /\n" +
                "      (@           `--------` ",1);
        print("+--------------------------------------------------------------------------------------------+",1);
        print("[1]Play",1);
        int decision= inputInt();
        if (decision==1){
            startGame();
        }
        else if (decision==2){
            System.exit(1);
        }


    }

    public static void startGame() {
        print("+--------------------------------------------------------------------------------------------+",1);
        print("                                     Beginner Stats",1);
        print("Knight \n" +
                "[HP]: 30, [ATK]: 15, [DEF]: 8, [MP]: 5",1); // display stats
        Hero player= new Knight(); // creates player object
        print("+--------------------------------------------------------------------------------------------+",1);
        print("                                     GAME START!",1);
        tutorial(player); 

    }

    public static void tutorial(Hero player) {
        print("Welcome to Untitled Adventure Game!\n To survive these dungeons, you need to know how to fight. Let us start the battle simulation.",1);
        Enemy enemy= new troll(2); //creates enemy object
        inputString();
        battle(player, enemy);
        print("Good job! Now you are ready to venture forth",1);


    }
   public static void game(Hero player) {
        boolean complete = false;
        Dungeon dungeon = generateDungeon();
        dungeon.getRooms();
        print(dungeon.getRoom(), 1);
        while (true) {
            if(dungeon.getCurrentroom()==5){
                break;
            }
            print(dungeon.getRoom(), 1);
            while (dungeon.getSteps() < 5){
                if (dungeon.getSteps() == 4) {
                    print("You are 1 step away from a enemy!", 1);
                }
                print("press enter to step forward", 1);
                inputString();
                dungeon.Step();
                dungeon.setCurrentroom(1);

            }
            Enemy enemy= dungeon.battles(dungeon.getCurrentroom());
            battle(player,enemy);

        }
        print("You have won!",1);


    }

    public static Dungeon generateDungeon(){
        Random random= new Random();
        Dungeon dungeon= new Dungeon(random.nextInt(10 - (3) + 1) + (3)); //generates rooms randomly between 3-10);
        return dungeon;
    }

    public static void battle(Hero player, Enemy enemy) {
        Random random = new Random();
        int turn=0;
            print("+--------------------------------------------------------------------------------------------+",1);
            print("                             "+enemy.getDescription(),1);
            boolean escaped=false;// used for escape function
        while (enemy.getHP()>0){ // will loop as long as enemy is alive or loop breaks.
            int choice;
            if (turn==0){
                if(player.deathCheck()){
                    gameover(); // when looping, it will check to see if the player is dead
                }
                print("***PLAYER TURN***",1);

                print(enemy.getPortrait(), 1);
                print("["+enemy.getName()+"]",1);
                print("\n<<<ENEMY HP: "+enemy.getHP()+">>>",1);
                print("\n<<<PLAYER HP: "+player.getHP()+">>>",1);// display stats and options
                print("\nWhat would you like to do?\n[1]Attack\n[[2]Heal\n[3]Run",1);
                choice=inputInt();

                if (choice==1){
                    player.Attack(enemy); // attacks enemy
                    turn=1; // enemy turn
                    continue; // loop again
                }

                if (choice==2){
                    player.Heal(player); // heals player
                    turn=1; //enemy turn
                    continue; //loop

                }

                if (choice==3){
                    int escapeChance= random.nextInt(2*enemy.getLevel() - (1) + 1) + (1); // calculates chance for esacpe
                    if (escapeChance==2){
                        escaped=true; // if the random value is equal to 2, it will break loop and player will escape
                        break;
                    }
                    else{
                        turn=1; // if not, escape fails and loops again
                        continue;
                    }
                }
            }
            if(turn==1){
                print("\n ***ENEMY TURN***",1);
                enemy.Attack(player); // enemy by default will attack player
                turn=0; // player turn
                continue;

            }
        }
        if (escaped){
            printResults(player,0); // will display results of battle and give player 0 xp

        }
        else{
            //System.out.println(enemy.getLevel());
            printResults(player, Math.round(4 * enemy.getLevel() ^ 3 / 5)); //calculates xp based on enemy's level

        }
    }

    public static void printResults(Hero player, int xp){
        player.increaseXP(xp); // increases xp of player
        player.levelUp(); // checks to see if the player has levelled up
        print("You have gained: "+xp+"xp!",1); // prints results
        print("PLAYER [LEVEL:"+player.getLevel()+"]"+"      XP: "+player.getXP()+"/"+player.getXPnext(),1);

    }

    public static void gameover() {
        print("***YOU DIED***\n Game Over!",1);
        System.exit(0); // program ends if player dies

    }

    private static Hero createCharacter() {
        int choice= inputInt();
        if (choice==1){
            Hero character= new Knight();
            return character;
        }
        else{
            return null;
        }
    }
// input and print methods

    public static void print(String text, int line){ 
        if (line==1) {
            System.out.println(text);
        }
        else if (line==0){
            System.out.print(text);
        }
    }

    public static int inputInt(){
        Scanner scanner = new Scanner(System.in);
        int x=scanner.nextInt();
        return x;

    }
    public static String inputString(){
        Scanner scanner = new Scanner(System.in);
        String x=scanner.nextLine();
        return x;

    }
}
