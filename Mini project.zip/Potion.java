public class Potion {
    private int healAmount;
    private int LVL;
    private int quantity;

    public Potion(int quantity){
        healAmount= 10;// healing amount when heal method is executed
        this.quantity= quantity; 
    }

    public void Heal(Hero Hero){
        if(quantity==0){
            System.out.println("You have no potions left!");// if there are no potions left, it will display this message 

        }
        else{
            Hero.setHP(healAmount,true); // add the heal amount to player
            quantity-=1; // reduces quantity
            if (Hero.getHP()>Hero.getMaxHP()){ // if the HP exceeds the max HP, it will make sure the HP will be back to maxHP
                int calculation= Hero.getHP()-Hero.getMaxHP(); // calculation to find difference between current hp and max hp, and it subtracts it from current hp
                System.out.println(Hero.getHP());

                Hero.setHP(calculation,false);
            }
            System.out.println("Your HP is now: "+Hero.getHP()); //displays current hp
        }
    }
}
