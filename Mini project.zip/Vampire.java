class Vampire extends Enemy{

    public Vampire(int LVL) {
        super("Vampire", 5*LVL, LVL, 15*LVL, 5*LVL, 5*LVL); //sets level and attributes
    }
    public String getDescription(){
        return "A Vampire want your blood!";
    }
    public String getPortrait(){
        return "              __.......__\n" +
                "            .-:::::::::::::-.\n" +
                "          .:::''':::::::''':::.\n" +
                "        .:::'     `:::'     `:::. \n" +
                "   .'\\  ::'   ^^^  `:'  ^^^   '::  /`.\n" +
                "  :   \\ ::   _.__       __._   :: /   ;\n" +
                " :     \\`: .' ___\\     /___ `. :'/     ; \n" +
                ":       /\\   (_|_)\\   /(_|_)   /\\       ;\n" +
                ":      / .\\   __.' ) ( `.__   /. \\      ;\n" +
                ":      \\ (        {   }        ) /      ; \n" +
                " :      `-(     .  ^\"^  .     )-'      ;\n" +
                "  `.       \\  .'<`-._.-'>'.  /       .'\n" +
                "    `.      \\    \\;`.';/    /      .'\n" +
                " jgs  `._    `-._       _.-'    _.'\n" +
                "       .'`-.__ .'`-._.-'`. __.-'`.\n" +
                "     .'       `.         .'       `.\n" +
                "   .'           `-.   .-'           `.";
    }
}