public class Weapon {
    private String name;
    private int ATK; //stats
    private int CRIT;
    private int SPEC;

    public Weapon(String Name, int attack, int critical, int special){
        name=Name;
        ATK=attack;
        CRIT=critical;
        SPEC=special;
    }

    public String getName(){ //getters and setters
        return name;
    }

    public int getATK(){
        return ATK;
    }

    public int getCRIT(){
        return CRIT;
    }

    public int getSPEC(){
        return SPEC;
    }
}

class IronSword extends Weapon{

    public IronSword(){
        super("Iron Sword", 10,0,0); 
    }
}

class epicSword extends Weapon{

    public epicSword(){
        super("epic sword", 30,30,5);
    }
}

